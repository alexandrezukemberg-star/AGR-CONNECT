// Preencha SOMENTE depois de criar um projeto Supabase próprio para AGR CONNECT.
// A chave publicável é adequada ao navegador; NUNCA use service_role ou secret keys aqui.
window.AGR_CONFIG = {
  url: '',
  publishableKey: ''
};
